#include <cstdio>
#include <vector>

using namespace std;

// 归并排序
void mergeArray(vector<int>& a, int low, int mid, int high, vector<int>& tmp) {
    int i = low, j = mid + 1, m = mid, n = high, k = 0;
    while (i <= m && j <= n) {
        if (a[i] <= a[j])
            tmp[k++] = a[i++];
        else
            tmp[k++] = a[j++];
    }
    while (i <= m)
        tmp[k++] = a[i++];
    while (j <= n)
        tmp[k++] = a[j++];
    for (i = 0; i < k; ++i)
        a[low + i] = tmp[i];
}
void mergeSort(vector<int>& a, int low, int high, vector<int>& tmp) {
    if (low < high) {
        int mid = (low + high) / 2;
        mergeSort(a, low, mid, tmp);
        mergeSort(a, mid + 1, high, tmp);
        mergeArray(a, low, mid, high, tmp);
    }
}
void MergeSort(vector<int>& a, int n) {
    vector<int> p(n);
    if (p.size() == 0)
        return;
    mergeSort(a, 0, n - 1, p);
}

int main() {
    // 文件输入输出
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    int n;
    scanf("%d", &n);
    vector<int> a(n);
    for (int i = 0; i < n; ++i) {
        int x;
        scanf("%d", &x);
        a[i] = x;
    }

    MergeSort(a, n);  // 排序

    printf("%d\n", n);
    for (int i = 0; i < n; ++i)
        printf("%d%s", a[i], i == n - 1 ? "\n" : " ");

    return 0;
}